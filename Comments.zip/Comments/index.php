﻿<?php require_once 'comments.php';?> 
<!DOCTYPE html>
<html>
	<head>
		<title>Index</title>
		<link href="style.css" rel="stylesheet">
		<script type="text/javascript" src="jquery-1.4.4.min.js"></script>
		<script type="text/javascript" src="comment.js"></script>
	</head>
	<body>
		<ul id="commentRoot">
			<?php echo $comments;?>
			<li id="newComment">
				<div class="commentContent">
					<div id ="cancelComment">X</div>
					<h6>Ваше имя:<input name="name" type="text"><span></span> </h6>
					<div class="comment">
						Комментарий:
						<textarea name="newCommentText"></textarea>
					</div>
					<button>Сохранить</button><img class="loader" src.="loader.gif">
				</div>
			</li>
		</ul>
		<button id="addNewComment">Добавить комментарий</button>
	</body>
</html>