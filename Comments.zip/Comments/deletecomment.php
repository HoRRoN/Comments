<?php
    if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') {
		sleep(3);
        if($_POST[parent_id])  $parent_id = preg_replace('/\D+/i','', $_POST[parent_id]);
        else $parent_id = 0;        
        $author = trim($_POST[author]);
        $comment = trim($_POST[comment]);
        if(!$author)   $error[author] = 'Введите имя!';
        if(!$comment)  $error[comment] = 'Напишите комментарий!';
        if($error) exit(json_encode($error));
        require_once 'comdb.php';  
        $sql = "DELETE FROM comments WHERE id = $note_id";
		$sql = "DELETE FROM comments WHERE parent_id = $note_id";
        $result = mysql_query($sql);
        if(!$result){
            $error[] = 'Произошла ошибка, комментарий не удален';
            exit(json_encode($error));
        }
        exit();
    }
	
?>	
         